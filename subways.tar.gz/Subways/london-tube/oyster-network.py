#!/usr/bin/python

import sys
import re

########################
def flatten(x):
	result = []
	for el in x:
		if hasattr(el, "__iter__") and not isinstance(el, basestring):
			result.extend(flatten(el))
		else:
			result.append(el)
	return result


def aggregate(x):
	s=""
	if len(x)==0: return("")
	for i in x[0:len(x)-1]:	s+=i+", "
	return(s+x[len(x)-1])

#list2dict returns a dictionary {1:"A",2:"B",3:"C"...} from a list [["A",x,1],["B",y,2],["C",z,2]]
def list2dict(l):
	dict={}
	for i in l:
		j,k,m=i[0],i[1],i[2]
		if m not in dict: dict.setdefault(m,[])
		dict[m].append([j,k])
	return(dict)
	
p=re.compile(r'\t+') #splits a string into bits separated by tabs ("\t")

########################

print "*** metro network constructor v0.2 (090615)"

if len(sys.argv)<3:
    sys.exit("usage: "+sys.argv[0]+" [index file] [date]")
 
lines_filename=sys.argv[1]

mydate=int(sys.argv[2])

lines={}
lines_next={}
lines_prev={}
lines_heads={}
lines_tails={}
lines_stations={}
nlines=0

stations_neighbors={}
stations_name={}
stations_date={}
nstations=0

print "\nprocessing index file of lines... (opening \""+lines_filename+"\")"
#opening index file for lines
lines_file=open(lines_filename,"r")
s=(lines_file.readline()).split()
metro_name,stations_filename,stations_exceptions_filename=s[0],s[1],s[2]
for s in lines_file:
	ps=s.split()
	lines.setdefault(ps[0],[nlines,ps[1],ps[2]])
	lines_next.setdefault(ps[0],{})
	lines_prev.setdefault(ps[0],{})
	lines_tails.setdefault(ps[0],[])
	lines_heads.setdefault(ps[0],[])
	lines_stations.setdefault(ps[0],[])
	stations_date.setdefault(ps[0],{})
	nlines+=1
lines_file.close()

print "   processed information for",nlines,"lines."

print "\n*** constructing metro network of",metro_name,"in",mydate,"for \""+lines_filename+"\" (date information:",stations_filename+")...\n"

#opening station opening date file
print "processing index file of stations... (opening \""+stations_filename+"\")"
stations_file=open(stations_filename,"r")
for s in stations_file:
	ps=s.split()
	real_name,opening_date=ps[0],ps[3]
	problem=0
	if (opening_date.isdigit()):
		if (int(opening_date)<1800) or (int(opening_date)>2050): problem=1
	else: problem=1
	if (problem==1): print "*** problem with",ps[0],": opening date is",opening_date
	stations_name.setdefault(nstations,real_name)
	stations_name.setdefault(real_name,nstations)
	for l in lines.keys():
		stations_date[l].setdefault(nstations,opening_date)
		stations_date[l].setdefault(real_name,opening_date)
	nstations+=1
stations_file.close()
#stations_name is a both-ways dictionary associating ids and names of stations
#stations_date is a dictionary of dictionaries associating indifferently station ids/names with their opening date
print "   processed information for",nstations,"stations."

print "processing exception file for opening dats of stations... (opening \""+stations_exceptions_filename+"\")"
stations_exceptions_file=open(stations_exceptions_filename,"r")
nexceptions=0
for s in stations_exceptions_file:
	ps=s.split()
	stations_date[ps[1]][ps[0]]=ps[2]
	nexceptions+=1
stations_exceptions_file.close()
print "   processed",nexceptions,"exception(s).\n"

unknownstations=[]
for l in lines.keys():  
	#l is the name of the line currently processed
	print "processing adjacency file for the",l,"line (#"+str(lines[l][0])+", est.",lines[l][2]+")... (opening \""+lines[l][1]+"\")"
	f=open(lines[l][1],"r")
	for s in f:
		ps=s.split()
		orig,dest=ps[0],ps[1]
		if orig not in stations_name: 
			print "*** problem with",orig+": unknown station name."
			unknownstations.append(orig)
		if dest not in stations_name: 
			print "*** problem with",dest+": unknown station name."
			unknownstations.append(dest)
		if orig not in lines_stations[l]: lines_stations[l].append(orig)
		if dest not in lines_stations[l]: lines_stations[l].append(dest)
		if orig not in lines_next[l]:
			lines_next[l].setdefault(orig,[])
		lines_next[l][orig].append(dest)
		if dest not in lines_prev[l]:
			lines_prev[l].setdefault(dest,[])
		lines_prev[l][dest].append(orig)
	for s in lines_stations[l]:
		if s not in lines_prev[l]: lines_heads[l].append(s)
		if s not in lines_next[l]: lines_tails[l].append(s)
	print "   ",len(lines_stations[l]),"stations,",len(lines_heads[l]),"head(s) ("+aggregate(lines_heads[l])+"),",len(lines_tails[l]),"tail(s) ("+aggregate(lines_tails[l])+")"
	f.close()

if len(unknownstations)>0:
	print "\n*** a dictionary problem occured, the following stations are not part of station index file \""+stations_filename+"\":\n    ",aggregate(unknownstations)
	quit()

#####

# follow_line returns under "activelist" the list of stations open at date "date" and following "station" on a line described by "graph"
#   "activelist" is a list of pairs [station name, distance] where "distance" represents the distance from "station"
#   "absdist" contains the distance at the given date, i.e. not counting future stations. (it is correct at date "date")
#   "dist" contains the distance irrespective of the date, for the final network. (it is formal)
#   NB: checklist is an anti-loop device, should be activated with an empty list at first ("[]").
def follow_line(graph,line,station,date,activelist,checklist,dist,absdist):
	ondate=0
	if int(stations_date[line][station])<date: ondate=1
	if station in graph:
		if ondate==1: activelist.append([station,dist,absdist])
		checklist.append(station)
		for s in graph[station]:
			loop=0
			if s in checklist: loop=1
			if loop==0:
				follow_line(graph,line,s,date,activelist,checklist,dist+1,absdist+ondate)
	else: 
		if ondate==1: activelist.append([station,dist,absdist])
		checklist.append(station)

def first_follow_line(graph,line,station,date,checklist):
	checklist.append(station)
	local_list=[]
	if station in graph: #does "station" have a follower in the dictionary?
		for s in graph[station]:
			loop=0
			if s in checklist: loop=1
			if loop==0:
				if int(stations_date[line][s])<date:
					local_list.append(s)
				else:
					local_list.append(first_follow_line(graph,line,s,date,checklist))
	return(flatten(local_list))


#####
#lists all neighbors of "fromstation" on "fromline" at date "date"
def neighbors(fromline,fromstation,date):
	tmplist=[]
	follow_line(lines_prev[fromline],fromline,fromstation,date,tmplist,[],0,0)
	print "--- on the",fromline,"line, starting from",fromstation,"in",str(date)+", the path is:"
	print "  *** backwards ***",list2dict(tmplist)
	tmplist=[]
	follow_line(lines_next[fromline],fromline,fromstation,date,tmplist,[],0,0)
	print "  *** forwards  ***",list2dict(tmplist)

#list the closest neighbors of "fromstation" on "fromline" at date "date"
def firstneighbors(fromline,fromstation,date):
	backwardlist=first_follow_line(lines_prev[fromline],fromline,fromstation,date,[])
	forwardlist=first_follow_line(lines_next[fromline],fromline,fromstation,date,[])
	links=[]
	for b in backwardlist:
		links.append([b,fromstation])
		links.append([fromstation,b])
	for b in forwardlist:
		links.append([b,fromstation])
		links.append([fromstation,b])
	#uncomment following line to have the list of pairwise links 
	#print "    ",backwardlist,"-",fromstation,"-",forwardlist,":",len(links)/2,"symmetric link(s)"
	return(links)
#####

print "\nnow constructing the network in",str(mydate)+"..."

network_links=[]
for l in lines.keys():
	for s in lines_stations[l]:
		if int(stations_date[l][s])<mydate:
			network_links.append(firstneighbors(l,s,mydate))
	print "    ",l,"line:",len(network_links),"total \"connections\"."

########
#network matrix construction

network_matrix=[[0 for i in range(nstations)] for i in range(nstations)]

for b in network_links:
	for c in b:
		network_matrix[stations_name[c[0]]][stations_name[c[1]]]=1
nlinks=0
for i in range(nstations):
	nlinks+=sum(network_matrix[i])
print "\nmatrix built:",nlinks,"total links."

matrix_filename=metro_name+"-"+str(mydate)+"-matrix.mat"
matrix_file=open(matrix_filename,"w")
print "   exporting it into \""+matrix_filename+"\" (Pajek format, but warning: Pajek is buggy on this)..."
matrix_file.writelines(["*Vertices ",str(nstations)+"\r\n"])
for i in range(nstations):
	matrix_file.writelines([str(i+1)," \"",stations_name[i],"\"\r\n"])
matrix_file.writelines(["*Matrix\r\n"])
t=0
for i in range(nstations):
	k=""
	for j in range(nstations): 
		k+="1 "#str(network_matrix[i][j])+" "
	matrix_file.writelines([k,"\r\n"])

matrix_file.close()
print "   done."

########
#adjacency list construction

network_adjacency={}
for i in range(nstations):
	for j in range(nstations):
		if network_matrix[i][j]==1:
			si=stations_name[i]
			sj=stations_name[j]
			if si not in network_adjacency:
				network_adjacency.setdefault(si,[])
			network_adjacency[si].append(sj)

print "\nadjacency list built:",len(network_adjacency.keys()),"keys."

adjacency_filename=metro_name+"-"+str(mydate)+"-adjacency.txt"
adjacency_file=open(adjacency_filename,"w")
print "   exporting it into \""+adjacency_filename+"\"..."

for b in network_adjacency.keys():
	for c in network_adjacency[b]:
		adjacency_file.writelines([b,"\t",c,"\n"])
adjacency_file.close()

pajek_filename=metro_name+"-"+str(mydate)+"-adjacency.net"
pajek_file=open(pajek_filename,"w")
print "   exporting it into \""+pajek_filename+"\" (Pajek format)..."

pajek_file.writelines(["*Network\r\n*Vertices "+str(nstations)+"\r\n"])#str(len(network_adjacency.keys()))+"\r\n"])
for b in network_adjacency.keys():
	pajek_file.writelines([str(stations_name[b]+1)," \"",b,"\"\r\n"])
pajek_file.writelines(["*Edges\r\n"])
for b in network_adjacency.keys():
	for c in network_adjacency[b]:
		pajek_file.writelines([str(stations_name[b]+1)," ",str(stations_name[c]+1)," 1\r\n"])
pajek_file.close()	

print "   done."
	
print "\n*** job finished."
quit()


##############################
##############################
###########GARBAGE############
##############################
##############################
#firstneighbors("Piccadilly","ActonTown",mydate)
lignesdemondepart=[]
for l in lines.keys():
	if mondepart in lines_stations[l]: lignesdemondepart.append(l)
print "\n---",mondepart,"(est.",stations_date[l][mondepart]+") is on line(s): ",lignesdemondepart
for l in lignesdemondepart:
	firstneighbors(l,mondepart,mydate)


#print stations_name
#print stations_neighbors



