#!/usr/bin/python

import sys
import re

print "*** london stations: quick merger for opening years and positions"

positionsfilename="list_stations_positions-clean.txt"
positionsfile=open(positionsfilename,"r")

positions={}
for p in positionsfile:
	ps=p.split()
	name=ps[0]
	long=ps[-1:][0]
	lat=ps[-2:-1][0]
	#print name+": "+lat+"E "+long+"N"
	positions.setdefault(name,{"lat":lat,"long":long,"year":0})
	
positionsfile.close()

yearsfilename="tube-stations-time.txt"
yearsfile=open(yearsfilename,"r")


minyear=100000000
for y in yearsfile:
	ys=y.split()
	name=ys[0]
	year=ys[3]
	if int(year)<minyear: minyear=int(year)
	positions[name]["year"]=year
	#print name+": ",year

yearsfile.close()

namesort=positions.keys()#. sort()
namesort.sort()

print '    - for information: minimum year is',minyear

print '--- processed "'+positionsfilename+'" and "'+yearsfilename+'".'

outputfilename="list_stations_positions_years.txt"
print '+++ now creating "'+outputfilename+'"...'
outputfile=open(outputfilename,"w")
for name in namesort:
	p=positions[name]
	lat,long,year=p['lat'],p['long'],p['year']
	if (str(year)!="0"): 
		outputfile.writelines([name,"\t",long,"\t",lat,"\t",year,"\n"])

outputfile.close()
print '--- done, exiting.'



